const express = require("express");
const router = express.Router();

// GET /api/students
router.get("/", (req, res) => {
  res.send("🎉 Student API is working!");
});

// POST /api/students
router.post("/", (req, res) => {
  const { name, age } = req.body;

  if (!name || !age) {
    return res.status(400).json({ error: "Name and age are required" });
  }
  console.log("📥 New student received:", { name, age });
  res.status(201).json({
    message: "Student created successfully",
    data: { name, age }
  });
});
module.exports = router;
