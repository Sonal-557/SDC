# Experiment 10: JWT Authentication API with Node.js and Express

This experiment demonstrates how to build a secure REST API using Node.js, Express, and JSON Web Tokens (JWT) for authentication. The API allows users to register, log in, and access protected student data endpoints.

---

## Folder Structure

```
Experiment10/
└── jwt-auth-api/
    ├── app.js                      # Main Express app setup
    ├── index.js                    # Entry point to start the server
    ├── JWT_SECRET=your_jwt_secret_key.env  # Environment variable for JWT secret
    ├── package.json                # Project dependencies and scripts
    ├── Readme.md                   # Project documentation
    ├── controllers/
    │   └── userController.js       # Handles user registration and login logic
    ├── middleware/
    │   └── authMiddleware.js       # JWT authentication middleware
    └── routes/
        └── students.js             # Student-related protected routes
```

---

## Features

- **User Registration:**  
  Users can register with a username and password.

- **User Login:**  
  Registered users can log in to receive a JWT token.

- **JWT Authentication:**  
  Protected routes require a valid JWT token in the `Authorization` header.

- **Student Routes:**  
  Access and manage student data only if authenticated.

---

## How to Run

1. **Install dependencies:**  
   In the `jwt-auth-api` folder, run:
   ```sh
   npm install
   ```

2. **Set up environment variable:**  
   Create a `.env` file or ensure `JWT_SECRET=your_jwt_secret_key.env` is present with your secret key.

3. **Start the server:**  
   ```sh
   node index.js
   ```

4. **API will be available at:**  
   [http://localhost:3000](http://localhost:3000)

---

## Example API Usage

- **Register a user:**
  ```sh
  curl -X POST -H "Content-Type: application/json" -d '{"username":"alice","password":"mypassword"}' http://localhost:3000/register
  ```

- **Login and get JWT token:**
  ```sh
  curl -X POST -H "Content-Type: application/json" -d '{"username":"alice","password":"mypassword"}' http://localhost:3000/login
  ```
  Response will include a JWT token.

- **Access protected student route:**
  ```sh
  curl -H "Authorization: Bearer <your_token_here>" http://localhost:3000/students
  ```

---

## Notes

- Passwords should be hashed in production (for demo, they may be stored as plain text).
- JWT tokens must be included in the `Authorization` header as `Bearer <token>`.
- Student routes are protected and require authentication.

---

## Requirements

- [Node.js](https://nodejs.org/)
- [Express](https://expressjs.com/)
- [jsonwebtoken](https://www.npmjs.com/package/jsonwebtoken)

---

*This experiment helps you understand how to implement secure authentication in Node.js APIs using