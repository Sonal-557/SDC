const express = require('express');
const app = express();

app.use(express.json()); // To parse JSON request bodies

let students = [
    { id: 1, name: "Alice", age: 20 },
    { id: 2, name: "Bob", age: 22 }
];

// Get all students
app.get('/students', (req, res) => {
    res.json(students);
});

// Get student by ID
app.get('/students/:id', (req, res) => {
    const student = students.find(s => s.id === parseInt(req.params.id));
    if (!student) return res.status(404).send("Student not found");
    res.json(student);
});

// Create new student
app.post('/students', (req, res) => {
    const { name, age } = req.body;
    const newStudent = {
        id: students.length + 1,
        name,
        age
    };
    students.push(newStudent);
    res.status(201).json(newStudent);
});

// Update student
app.put('/students/:id', (req, res) => {
    const student = students.find(s => s.id === parseInt(req.params.id));
    if (!student) return res.status(404).send("Student not found");

    const { name, age } = req.body;
    student.name = name;
    student.age = age;
    res.json(student);
});

// Delete student
app.delete('/students/:id', (req, res) => {
    const studentIndex = students.findIndex(s => s.id === parseInt(req.params.id));
    if (studentIndex === -1) return res.status(404).send("Student not found");

    const deleted = students.splice(studentIndex, 1);
    res.json(deleted[0]);
});

// Start server
app.get('/', (req, res) => {
    res.send('Welcome to the Student API!');
});

const PORT = 3003;
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});


// node index.js
// To run the server, use the command: node index.js
// URL: http://localhost:3003/students