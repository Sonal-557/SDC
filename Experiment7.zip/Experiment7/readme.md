# Experiment 7: Express.js CRUD API for Students

This experiment demonstrates how to build a simple RESTful API using [Express.js](https://expressjs.com/) in Node.js. The API allows you to perform CRUD (Create, Read, Update, Delete) operations on a list of students stored in memory.

---

## Folder Structure

```
Experiment7/
├── index.js         # Main server file with API logic
└── package.json     # Project metadata and dependencies
```

---

## Features

- **List all students:**  
  `GET /students`  
  Returns a JSON array of all students.

- **Get a student by ID:**  
  `GET /students/:id`  
  Returns a single student object if found.

- **Add a new student:**  
  `POST /students`  
  Accepts JSON `{ "name": "...", "age": ... }` and adds a new student.

- **Update a student:**  
  `PUT /students/:id`  
  Updates the name and age of the student with the given ID.

- **Delete a student:**  
  `DELETE /students/:id`  
  Removes the student with the specified ID.

- **Welcome route:**  
  `GET /`  
  Returns a welcome message.

---

## How to Run

1. **Install dependencies** (only needed once):
   ```sh
   npm install
   ```

2. **Start the server:**
   ```sh
   node index.js
   ```

3. **API will be available at:**  
   [http://localhost:3003](http://localhost:3003)

---

## Example Usage

- **Get all students:**  
  [GET http://localhost:3003/students](http://localhost:3003/students)

- **Add a student (using curl):**
  ```sh
  curl -X POST -H "Content-Type: application/json" -d '{"name":"Charlie","age":23}' http://localhost:3003/students
  ```

- **Update a student:**
  ```sh
  curl -X PUT -H "Content-Type: application/json" -d '{"name":"Alice Updated","age":21}' http://localhost:3003/students/1
  ```

- **Delete a student:**
  ```sh
  curl -X DELETE http://localhost:3003/students/2
  ```

---

## Notes

- The student data is stored in memory (an array), so changes are lost when the server restarts.
- The API expects and returns JSON data.
- You can use tools like [Postman](https://www.postman.com/) or [curl](https://curl.se/) to test the endpoints.

---

## Requirements

- [Node.js](https://nodejs.org/) (v14 or higher recommended)
- [Express.js](https://expressjs.com/) (installed via `npm install`)

---

*This experiment helps you understand the basics of building RESTful APIs with Express.js